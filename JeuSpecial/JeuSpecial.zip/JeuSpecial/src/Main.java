import javax.print.attribute.HashDocAttributeSet;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws InterruptedException {

        boolean quitter = false;
        //Déclaration Jeu
        Jeu jeu = new Jeu();
        //Déclaration tableau de jeu
        Matrice tabJeu = new Matrice(20,20);
        //Menu accueuiil
        jeu.accueuil();
        //Lancement Jeu
        while(!jeu.isQuitter() && jeu.personnage.nbreBossTues != 3){
            //Affiche le tableau
            tabJeu.afficherJeu(jeu.afficherJeuComplet);
            //Jouer decision
            jeu.bouger(tabJeu);
            //Respawn si des troupes tuées
            tabJeu.repeupler();
        }


    }






}