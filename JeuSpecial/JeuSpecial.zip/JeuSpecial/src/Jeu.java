import org.w3c.dom.ls.LSOutput;

import java.util.Random;
import java.util.Scanner;

public class Jeu {

    boolean quitter;

    int pointeur = 0;

    boolean decisionPrise = false;

    boolean afficherJeuComplet = false;

    Personnage personnage;

    public Jeu() {
        quitter = false;
        personnage = new Personnage(10);
        personnage.setArme(new Poing(2));
        personnage.setNom("Arthur");
    }


    public void accueuil() throws InterruptedException {

        Scanner clavier = new Scanner(System.in);

        decisionPrise = false;
        pointeur = 0;
        boolean sortir = false;

        while(!sortir){
            while(!decisionPrise){

                affAcueuil();

                String choix = clavier.nextLine();

                switch(choix.toUpperCase()){
                    case "W":
                        if(pointeur == 0){
                            pointeur = 3;
                        }else{
                            pointeur--;
                        }
                        break;
                    case "S":
                        if(pointeur == 3){
                            pointeur = 0;
                        }else{
                            pointeur++;
                        }
                        break;
                    case "":
                        decisionPrise = true;
                        break;
                    default:
                        System.out.println("s, w pour naviguer. Entree pour selecitonner le choix. :)");
                }
            }

            switch(pointeur){
                case 0:
                    //Quitter est deja a false
                    msgBienvenue();
                    sortir = true;
                    break;
                case 1:
                    parametres();
                    decisionPrise = false;
                    break;
                case 2:
                    afficherBlagues();
                    decisionPrise = false;
                    break;
                case 3:
                    quitter = true;
                    sortir = true;
                    break;
            }
        }




    }

    private void affAcueuil(){

        String jouer = "*          Jouer          *";
        String parametres = "*        Parametres       *";
        String blagues = "*         Blagues         *";
        String quitter = "*         Quitter         *";

        switch(pointeur){
            case 0:
                jouer =      "*     ---> Jouer <---     *";
                break;
            case 1:
                parametres = "*   ---> Parametres <---  *";
                break;
            case 2:
                blagues = "*    ---> Blagues <---    *";
                break;
            case 3:
                quitter = "*    ---> Quitter <---    *";

        }

        System.out.println("***************************");
        System.out.println(jouer);
        System.out.println(parametres);
        System.out.println(blagues);
        System.out.println(quitter);
        System.out.println("***************************");
    }

    public void bouger(Matrice tableau) throws InterruptedException {
        Scanner clavier = new Scanner(System.in);
        String choix = "";
        boolean choixPasFait = true;
        while(choixPasFait){
            boolean bouger = false;
            choixPasFait = false;
            System.out.print("À vous: ");
            choix = clavier.nextLine();

            switch(trouverValeurCase(tableau, choix)){
                case 0:
                    bouger = true;
                    break;
                case 1:
                    ouvrirCoffre();
                    bouger = true;
                    break;
                case 2:
                    Combat combatEnnemi = new Combat(personnage, false);
                    if(combatEnnemi.demarrerCombat()){
                        personnage.levelUp();
                        bouger = true;
                    }
                    break;
                case 3:
                    Combat combatBoss = new Combat(personnage, true);
                    if(combatBoss.demarrerCombat()){
                        personnage.levelUp();
                        personnage.levelUp();
                        personnage.levelUp();
                        personnage.levelUp();
                        personnage.levelUp();
                        personnage.nbreBossTues++;
                        bouger = true;
                    }
                    break;
            }

            if(bouger){
                switch(choix.toUpperCase()){
                    case "W":
                        tableau.bouger(3);
                        break;
                    case "A":
                        tableau.bouger(2);
                        break;
                    case "S":
                        tableau.bouger(0);
                        break;
                    case "D":
                        tableau.bouger(1);
                        break;
                    case "Q":
                    case "QUITTER":
                        quitter = true;
                        break;
                    case "M":
                    case "MENU":
                        Menu();
                        break;
                    default:
                        System.out.println("Pas compris");
                        choixPasFait = true;
                        break;
                }
            }


        }

    }

    public boolean isQuitter() {
        return quitter;
    }

    public void setQuitter(boolean quitter) {
        this.quitter = quitter;
    }

    public Personnage getPersonnage() {
        return personnage;
    }

    public void setPersonnage(Personnage personnage) {
        this.personnage = personnage;
    }

    public void ouvrirCoffre() throws InterruptedException {
        Random ran = new Random();

        switch(ran.nextInt(10)){

            case 0:
            case 1:
            case 2:
            case 3:
                personnage.levelUp();
                break;
            case 4:
            case 5:
                System.out.println("*****************************");
                System.out.println("*                           *");
                System.out.println("* OH NON! C'est un piège!!! *");
                System.out.println("*                           *");
                System.out.println("*****************************");
                Thread.sleep(3000);
                Combat combat = new Combat(personnage, false);
                combat.demarrerCombat();
                break;
            case 6:
            case 7:
            case 8:
                System.out.println();
                System.out.println();
                System.out.println("************************");
                System.out.println("*                      *");
                System.out.println("* Le coffre est vide ! *");
                System.out.println("*                      *");
                System.out.println("************************");
                System.out.println();
                System.out.println();
                Thread.sleep(3000);
                break;
            case 9:
                personnage.setArme(new Epee(10));
                System.out.println("**********************************");
                System.out.println("*                                *");
                System.out.println("* Vous avez trouve Excalibur !!! *");
                System.out.println("*                                *");
                System.out.println("**********************************");
                Thread.sleep(3000);
        }

    }

    public int trouverValeurCase(Matrice tableau, String choix){

        int x = tableau.cooPerso("x");
        int y = tableau.cooPerso("y");

        int valeurCase = 0;

        switch(choix.toUpperCase()){
            case "W":
                if(y > 0){
                    valeurCase = tableau.tab[y - 1][x].getOccupant();
                }
                break;
            case "A":
                if(x > 0){
                    valeurCase = tableau.tab[y][x - 1].getOccupant();
                }
                break;
            case "S":
                if(y + 1 < tableau.tabLargeur){
                    valeurCase = tableau.tab[y + 1][x].getOccupant();
                }
                break;
            case "D":
                if(x + 1 < tableau.tabLongueur){
                    valeurCase = tableau.tab[y][x + 1].getOccupant();
                }
                break;
        }

        return valeurCase;


    }

    public void statistiques(){
        pointeur = 0;
        boolean retour = false;
        Scanner clavier = new Scanner(System.in);
        while(!retour){
            decisionPrise = false;
            while(!decisionPrise){
                affStatistiques();
                String choix = clavier.nextLine();
                switch (choix.toUpperCase()){
                    case "W":
                        if(pointeur == 0){
                            pointeur = 2;
                        }else{
                            pointeur--;
                        }
                        break;
                    case "S":
                        if(pointeur == 2){
                            pointeur = 0;
                        }else{
                            pointeur++;
                        }
                        break;
                    case "":
                        decisionPrise = true;
                        break;
                    default:
                        System.out.println("s, w pour naviguer. Entree pour selecitonner le choix. :)");
                }
            }

            switch(pointeur){
                case 0:
                    if(personnage.getStats() > 0){
                        personnage.statsPV++;
                        personnage.stats--;
                    }
                    break;
                case 1:
                    if(personnage.getStats() > 0){
                        personnage.statsDegats++;
                        personnage.stats--;
                    }
                    break;
                case 2:
                    retour = true;
            }

        }




    }

    public void affStatistiques(){
        System.out.println("****************");
        System.out.println("* STATISTIQUES ");
        System.out.println("* PV: " + personnage.getStatsPV());
        System.out.println("* Degats: " + personnage.getStatsDegats());
        System.out.println("* Points de stats: " + personnage.getStats());
        System.out.println("****************");
        System.out.println();

        String ajoutPv = "      + 1 en PV";
        String ajoutDegats = "      + 1 en Degats";
        String retour = "      Retour";

        switch(pointeur){
            case 0:
                ajoutPv = " ---> + 1 en PV";
                break;
            case 1:
                ajoutDegats = " ---> + 1 en Degats";
                break;
            case 2:
                retour = " ---> Retour";
                break;
        }

        System.out.println(ajoutPv);
        System.out.println(ajoutDegats);
        System.out.println(retour);
    }

    public void Menu() throws InterruptedException {
        boolean retour  = false;
        Scanner clavier = new Scanner(System.in);
        while(!retour){
            decisionPrise = false;
            pointeur = 1;
            while(!decisionPrise){
                afficherMenu();

                String choix = clavier.nextLine();

                switch (choix.toUpperCase()){
                    case "W":
                        if(pointeur == 0){
                            pointeur = 3;
                        }else{
                            pointeur--;
                        }
                        break;
                    case "S":
                        if(pointeur == 3){
                            pointeur = 0;
                        }else{
                            pointeur++;
                        }
                        break;
                    case "":
                        decisionPrise = true;
                        break;
                    default:
                        System.out.println("s, w pour naviguer. Entree pour selecitonner le choix. :)");
                }



            }

            switch (pointeur){
                case 0:
                    statistiques();
                    break;
                case 1:
                    retour = true;
                    break;
                case 2:
                    parametres();
                    break;
                case 3:
                    retour = true;
                    quitter = true;
            }

        }



    }

    public void afficherMenu(){

        String statistiques = "*      Statistiques      *";
        String retour =  "*         Retour         *";
        String parametres = "*       Parametres       *";
        String quitter = "*        Quitter         *";


        switch(pointeur){
            case 0:
                statistiques = "* ---> Statistiques <--- *";
                break;
            case 1:
                retour = "*    ---> Retour <---    *";
                break;
            case 2:
                parametres = "*  ---> Parametres <---- *";
                break;
            case 3:
                quitter = "*   ---> Quitter <---    *";
        }

        System.out.println("**************************");
        System.out.println(statistiques);
        System.out.println(retour);
        System.out.println(parametres);
        System.out.println(quitter);
        System.out.println("**************************");
    }

    public void parametres() throws InterruptedException {
        pointeur = 0;
        boolean retour  = false;
        Scanner clavier = new Scanner(System.in);
        while(!retour){
            decisionPrise = false;
            while(!decisionPrise){
                afficherParametres();

                String choix = clavier.nextLine();

                switch (choix.toUpperCase()){
                    case "W":
                        if(pointeur == 0){
                            pointeur = 1;
                        }else{
                            pointeur--;
                        }
                        break;
                    case "S":
                        if(pointeur == 1){
                            pointeur = 0;
                        }else{
                            pointeur++;
                        }
                        break;
                    case "":
                        decisionPrise = true;
                        break;
                    default:
                        System.out.println("s, w pour naviguer. Entree pour selecitonner le choix. :)");
                }

            }

            switch (pointeur){
                case 0:
                    System.out.println("Change boolen");
                    afficherJeuComplet = !afficherJeuComplet;
                    break;
                case 1:
                    System.out.println("Retourne");
                    retour = true;
                    break;
            }

        }
    }

    public void afficherParametres() throws InterruptedException {

        String voirTouteMap = "*       Voir toute la map: " + afficherJeuComplet + "       *";
        String retour = "*                Retour                *";

        switch(pointeur){
            case 0:
                voirTouteMap = "*  ---> Voir toute la map: " + afficherJeuComplet + " <---  *";
                break;
            case 1:
                retour = "*           ---> Retour <---           *";
                break;
        }
        System.out.println("****************************************");
        System.out.println("*               Parametres             *");
        System.out.println(voirTouteMap);
        System.out.println(retour);
        System.out.println("****************************************");
    }

    public void afficherBlagues() throws InterruptedException {
        Random ran = new Random();
        switch(ran.nextInt(8)){
            case 0:
                System.out.print("Tu connais la blague à deux balles ?");
                Thread.sleep(3000);
                System.out.println(" Elle tue !");
                Thread.sleep(3000);
                break;
            case 1:
                System.out.println("Deux sardines se baladent quand l'une dit à l'autre : - Et si on allait en boîte ?");
                Thread.sleep(3000);
                break;
            case 2:
                System.out.println("Deux coccinelles font leur jogging. Soudain, l'une d'elles s'arrête et s'exclame : - Attends ! J'ai un point de côté.");
                Thread.sleep(3000);
                break;
            case 3:
                System.out.println("Sur une route, un escargot voit passer une limace et s'écrie : - Wow, la belle décapotable !");
                Thread.sleep(3000);
                break;
            case 4:
                System.out.println("Deux cons sont en voiture, soudain, la conductrice se met à crier : - Au secours, on n'a plus de frein ! - Ce n'est pas grave, dit l'autre. Il y a un stop en bas de la rue.");
                Thread.sleep(3000);
                break;
            case 5:
                System.out.print("Un chat prend un autre chat en photo et lui dit : - Souris ! L'autre chat sursaute : - Où ça, où ça ?");
                Thread.sleep(3000);
                break;
            case 6:
                System.out.print("Qu'est-ce qui a deux bosses et qu'on trouve au pôle Nord ?");
                Thread.sleep(3000);
                System.out.println("Un chameau qui est vraiment perdu.");
                Thread.sleep(3000);
                break;
            case 7:
                System.out.print("Qu'est-ce qui est jaune et qui est dans l'arbre ?");
                Thread.sleep(3000);
                System.out.println("La voiture du facteur qui a raté le virage.");
                Thread.sleep(3000);
                break;
        }
    }

    public void msgBienvenue() throws InterruptedException {

        Scanner clavier = new Scanner(System.in);

        System.out.println();
        System.out.println("        _\n" +
                "       / \\      _-'\n" +
                "     _/|  \\-''- _ /\n" +
                "__-' { |          \\\n" +
                "    /             \\\n" +
                "    /       \"o.  |o }\n" +
                "    |            \\ ;\n" +
                "                  ',\n" +
                "       \\_         __\\\n" +
                "         ''-_    \\.//\n" +
                "           / '-____'\n" +
                "          /\n" +
                "        _'\n" +
                "      _-'");
        System.out.println();
        Thread.sleep(500);

        String message = "Bienvenue jeune aventurier, le monde a besoin de ton aide. Trois faucheuses sont montées sur terre et terrorisent la population. ";
        String message2 = "Tuez les et devenez un héros. Faites attention, elles ont répandu leurs monstres partout. Faudra avancer avec prudence. ";
        String message3 = "Mais avant de partir, quel est votre nom?: ";
        String message4 = "Bienvenue . Bonne chance pour la suite de votre aventure. ";

        for(int i = 0; i < 28; i++){
            System.out.print(message.charAt(i));
            Thread.sleep(50);
        }
        Thread.sleep(500);
        for(int i = 28; i < 58; i++){
            System.out.print(message.charAt(i));
            Thread.sleep(50);
        }
        Thread.sleep(500);
        for(int i = 58; i < 129; i++){
            System.out.print(message.charAt(i));
            Thread.sleep(50);
        }
        System.out.println();
        Thread.sleep(500);
        for(int i = 0; i < 30; i++){
            System.out.print(message2.charAt(i));
            Thread.sleep(50);
        }
        Thread.sleep(500);
        for(int i = 30; i < 48; i++){
            System.out.print(message2.charAt(i));
            Thread.sleep(50);
        }
        Thread.sleep(500);
        for(int i = 48; i < 90; i++){
            System.out.print(message2.charAt(i));
            Thread.sleep(50);
        }
        Thread.sleep(500);
        for(int i = 90; i < 120; i++){
            System.out.print(message2.charAt(i));
            Thread.sleep(50);
        }
        System.out.println();
        Thread.sleep(500);
        for(int i = 0; i < 22; i++){
            System.out.print(message3.charAt(i));
            Thread.sleep(50);
        }
        Thread.sleep(500);
        for(int i = 22; i < 43; i++){
            System.out.print(message3.charAt(i));
            Thread.sleep(50);
        }

        do{
            personnage.setNom(clavier.nextLine());
            if(personnage.getNom().length() < 1){
                System.out.println("Aucun nom mis");
                System.out.print("Réesssayez: ");
            }else if(personnage.getNom().length() > 20){
                System.out.println("Maximum de 20 characteres");
                System.out.print("Réesssayez: ");
            }
        }while(personnage.getNom().length() < 1 && personnage.getNom().length() > 20);

        Thread.sleep(500);
        for(int i = 0; i < 10; i++){
            System.out.print(message4.charAt(i));
            Thread.sleep(50);
        }

        for(int i = 0; i < personnage.getNom().length(); i++){
            System.out.print(personnage.getNom().charAt(i));
            Thread.sleep(50);
        }
        System.out.print(". ");
        Thread.sleep(500);
        for(int i = 12; i < 58; i++){
            System.out.print(message4.charAt(i));
            Thread.sleep(50);
        }
        System.out.println();
        Thread.sleep(500);
        System.out.println();
        System.out.println();
        System.out.println();

    }

    public void msgFin() throws  InterruptedException {
        System.out.println();
        String message = "Merci de nous avoir sauvé valeureux combatant. Tu seras toujours le bienvenu parmi nous et en cas de besoin, nous serons toujours la pour toi.";
        System.out.println();
        System.out.println("        _\n" +
                "       / \\      _-'\n" +
                "     _/|  \\-''- _ /\n" +
                "__-' { |          \\\n" +
                "    /             \\\n" +
                "    /       \"o.  |o }\n" +
                "    |            \\ ;\n" +
                "                  ',\n" +
                "       \\_         __\\\n" +
                "         ''-_    \\.//\n" +
                "           / '-____'\n" +
                "          /\n" +
                "        _'\n" +
                "      _-'");


        System.out.println("**********   ***    ***   **********               **********   ****      **   **   ");
        System.out.println("**********   ***    ***   **********               **********   ****      **   **   ");
        System.out.println("**********   ***    ***   **                       **           ** **     **   **   ");
        System.out.println("    **       **********   **********               **********   **  **    **   **   ");
        System.out.println("    **       **********   **********               **********   **   **   **   **   ");
        System.out.println("    **       ***    ***   **                       **           **    **  **   **   ");
        System.out.println("    **       ***    ***   **********               **********   **     ** **   **   ");
        System.out.println("    **       ***    ***   **********               **********   **      ****   **   ");





    }


}
