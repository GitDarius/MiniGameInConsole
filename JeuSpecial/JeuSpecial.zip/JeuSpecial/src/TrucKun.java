public class TrucKun extends Arme{


    public TrucKun(int degats) {
        super(degats);
    }

    @Override
    public String posture(int ligne) {
        String[] lignes = new String[16];
         lignes[0] = "                                        ";
         lignes[1] = "                                        ";
         lignes[2] = "                                        ";
         lignes[3] = "                                        ";
         lignes[4] = "                                        ";
         lignes[5] = "                                        ";
         lignes[6] = "                                        ";
         lignes[7] = "                                        ";
         lignes[8] = "                                        ";
         lignes[9] = "                                        ";
        lignes[10] = "                                        ";
        lignes[11] = "               ___  ____________        ";
        lignes[12] = "             _/   ||            |       ";
        lignes[13] = "        ____/__|  ||            |       ";
        lignes[14] = "       )          ||____________|       ";
        lignes[15] = "       |___/O\\____/OO\\___/OO\\___/       ";


        return lignes[ligne];
    }

    @Override
    public String animation(int ligne) {
        String[] lignes = new String[16];
         lignes[0] = "                                        ";
         lignes[1] = "                                        ";
         lignes[2] = "                                        ";
         lignes[3] = "                                        ";
         lignes[4] = "                                        ";
         lignes[5] = "                                        ";
         lignes[6] = "                                        ";
         lignes[7] = "                                        ";
         lignes[8] = "                                        ";
         lignes[9] = "                                        ";
        lignes[10] = "                                        ";
        lignes[11] = "        ___  ____________               ";
        lignes[12] = "      _/   ||            |              ";
        lignes[13] = " ____/__|  ||            |              ";
        lignes[14] = ")          ||____________|              ";
        lignes[15] = "|___/O\\____/OO\\___/OO\\___/              ";

        return lignes[ligne];
    }

}
