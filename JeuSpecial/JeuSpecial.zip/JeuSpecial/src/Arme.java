public abstract class Arme {

    protected int degats;

    public abstract String posture(int ligne);

    public abstract String animation(int ligne);

    public int getDegats() {
        return degats;
    }

    public void setDegats(int degats) {
        this.degats = degats;
    }

    public Arme(int degats) {
        this.degats = degats;
    }



}
