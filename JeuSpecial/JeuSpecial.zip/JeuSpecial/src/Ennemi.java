public class Ennemi extends Etre{

    Arme arme;

    public Ennemi(int pv) {
        super(pv);

    }

    @Override
    public String afficherEtre(int ligne, boolean animation) {
        String[] lignes = new String[16];
         lignes[0] = "                                        ";
         lignes[1] = "                                        ";
         lignes[2] = "                                        ";
         lignes[3] = "                                        ";
         lignes[4] = "                                        ";
         lignes[5] = "                                        ";
         lignes[6] = "                                        ";
         lignes[7] = "                .-\"-.                   ";
         lignes[8] = "               /_ _  \\                  ";
         lignes[9] = "               \\@ @  /                  ";
        if(animation){
            lignes[10] = "               (_> _)                   ";
        }else{
            lignes[10] = "               (_= _)                   ";
        }
        lignes[11] = "                 `)(_                   ";
        lignes[12] = "                 /((_`)_,               ";
        lignes[13] = "                 \\__(/-\"                ";
        lignes[14] = "                __|||__                 ";
        lignes[15] = "               ((__|__))                ";


        return lignes[ligne];
    }




}
