public class Poing extends Arme{




    public Poing(int degats) {
        super(degats);
    }

    @Override
    public String posture(int ligne) {
        String[] lignes = new String[16];
         lignes[0] = "                                        ";
         lignes[1] = "                                        ";
         lignes[2] = "                                        ";
         lignes[3] = "                                        ";
         lignes[4] = "                                        ";
         lignes[5] = "                                        ";
         lignes[6] = "                                        ";
         lignes[7] = "                                        ";
         lignes[8] = "                                        ";
         lignes[9] = "       _______                          ";
         lignes[10] = "     /     ___\\                         ";
         lignes[11] = "    |       ___|                        ";
         lignes[12] = "    |       ___|                        ";
         lignes[13] = "     \\________/                         ";
         lignes[14] = "                                        ";
         lignes[15] = "                                        ";


        return lignes[ligne];
    }

    @Override
    public String animation(int ligne) {
        String[] lignes = new String[16];
         lignes[0] = "                                        ";
         lignes[1] = "                                        ";
         lignes[2] = "                                        ";
         lignes[3] = "                                        ";
         lignes[4] = "                                        ";
         lignes[5] = "                                        ";
         lignes[6] = "                                        ";
         lignes[7] = "                                        ";
         lignes[8] = "                                        ";
         lignes[9] = "                            _______     ";
        lignes[10] = "                          /     ___\\    ";
        lignes[11] = "                         |       ___|   ";
        lignes[12] = "                         |       ___|   ";
        lignes[13] = "                         \\________/     ";
        lignes[14] = "                                        ";
        lignes[15] = "                                        ";

        return lignes[ligne];
    }
}
